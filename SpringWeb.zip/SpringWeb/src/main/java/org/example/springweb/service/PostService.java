package org.example.springweb.service;

import org.example.springweb.Domain.*;
import org.example.springweb.repository.PostRepository;
import org.example.springweb.repository.PostRepositoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostService {
  private final PostRepository postRepository;
//  private final PostRepositoryImpl postRepositoryImpl;

  @Autowired
  public PostService(PostRepository postRepository) {
    this.postRepository = postRepository;
//    this.postRepositoryImpl = postRepositoryImpl;
  }

  public List<PostAllResponseDto> getAllPosts() {
    //return "PostService 가 호출되었습니다.";
    List<Post> allPosts = postRepository.findAll();
    List<PostAllResponseDto> postDtos = allPosts.stream()
        .map(PostAllResponseDto::of)
        .collect(Collectors.toList());
    return postDtos;
  }

  public PostDetailResponseDto getPostDetail(int postId) {
    Post post = postRepository.findById(postId);
    if (post == null) {
      return null;
    }
    PostDetailResponseDto retPost = new PostDetailResponseDto(
        post.getPostId(),
        post.getTitle(),
        post.getBody(),
        post.getLikes()
    );
    return retPost;
  }

  public void removePost(int postId) {
    postRepository.deletePost(postId);
  }

  public int increaseLikes(int postId) {
    Post post = postRepository.findById(postId);
    int likes = 0;
    if (post != null) {
      likes = post.getLikes() + 1;
      post.setLikes(likes);
    }
    return likes;
  }

  public PostDetailResponseDto createPost(PostCreateRequestDto postDto) {
    Post post = new Post(
        0,
        postDto.getTitle(),
        postDto.getBody(),
        0
    );
    int postId = postRepository.insertPost(post);
    return getPostDetail(postId);
  }

  public PostDetailResponseDto updatePost(PostUpdateRequestDto postDto) {
    Post post = postRepository.findById(postDto.getPostId());
    if (post != null && !postDto.getBody().equals("")) {
      post.setBody(postDto.getBody());
      postRepository.updatePost(post);
    }
    return getPostDetail(postDto.getPostId());
  }
}



