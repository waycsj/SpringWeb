package org.example.springweb.Domain;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@Data
@AllArgsConstructor
public class Post {

  private int postId;
  private String title;
  private String body;
  private int likes;
}
